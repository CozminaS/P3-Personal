
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Cozmina
 */
public class Comanda {
    private int id;
    private ArrayList <String> produse=new ArrayList<>();
    private double pret;
    private String status;

    public Comanda(int id, double pret, String status) {
        this.id = id;
        this.pret = pret;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ArrayList<String> getProduse() {
        return produse;
    }

    public void setProduse(ArrayList<String> produse) {
        this.produse = produse;
    }

    public double getPret() {
        return pret;
    }

    public void setPret(double pret) {
        this.pret = pret;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    
    
}
